#! /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt

#%% 1. BRANJE PODATKOV

praz = [] #csrs

#2D
file = open("apps2D.txt", "r")

for line in file:
    praz.append(line.split()[1])
praz = np.array(praz)
praz = praz.astype(np.float)

file.close()

#VISINE

dH = [] #csrs

file = open("apps_dH.txt", "r")

for line in file:
    dH.append(line.split()[1])
dH = np.array(dH)
dH = dH.astype(np.float)

file.close()

#%% 2. IZRIS PORAZDELITVE NAPAKE MED IZMERO - barchart, matplotlib

st_op1 = [] #spremeni, ko prebereš drugo datoteko
vrstice1 = 0 
for i in praz: #Spreminjaj glede na izris!
    st_op1.append(vrstice1)
    vrstice1 = vrstice1 + 1

#APPS
s1 = st_op1[0:318]
sop1 = st_op1[0:318]

s2 = st_op1[318:444]
sop2 = st_op1[0:126]

#%% 3. GRAFIČNI IZRIS

#%% HZ
width = 1.0 #sirina stolpca
width1 = 0.6

plt.figure(num=1,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('APPS 1. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop1,praz[s1],width,color='g',edgecolor='g',label='1. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=2,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('APPS 2. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop2,praz[s2],width1,color='g',edgecolor='g',label='2. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

#%% VIŠINE

plt.figure(num=3,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('APPS 1. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop1,dH[s1],width,color='r',edgecolor='r',label='1. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=4,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('APPS 2. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop2,dH[s2],width1,color='r',edgecolor='r',label='2. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')