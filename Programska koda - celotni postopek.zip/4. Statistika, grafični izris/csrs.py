#! /usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt

#%% 1. BRANJE PODATKOV

praz = [] #csrs

#2D
file = open("csrs2D.txt", "r")

for line in file:
    praz.append(line.split()[1])
praz = np.array(praz)
praz = praz.astype(np.float)

file.close()

#VISINE

dH = [] #csrs

file = open("csrs_dH.txt", "r")

for line in file:
    dH.append(line.split()[1])
dH = np.array(dH)
dH = dH.astype(np.float)

file.close()

#%% 2. IZRIS PORAZDELITVE NAPAKE MED IZMERO - barchart, matplotlib

st_op1 = [] #spremeni, ko prebereš drugo datoteko
vrstice1 = 0 
for i in praz: #Spreminjaj glede na izris!
    st_op1.append(vrstice1)
    vrstice1 = vrstice1 + 1

#CSRS
s1 = st_op1[0:307]
sop1 = st_op1[0:307]

s2 = st_op1[307:397]
sop2 = st_op1[0:90]

s3 = st_op1[397:597]
sop3 = st_op1[0:200]

s4 = st_op1[597:864]
sop4 = st_op1[0:267]

#%% 3. GRAFIČNI IZRIS

#%% HZ
width = 1.0
width1 = 0.6

plt.figure(num=1,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 1. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop1,praz[s1],width,color='g',edgecolor='g',label='1. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=2,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 2. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop2,praz[s2],width1,color='g',edgecolor='g',label='2. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=3,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 3. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='11')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop3,praz[s3],width,color='g',edgecolor='g',label='3. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=4,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 4. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop4,praz[s4],width,color='g',edgecolor='g',label='4. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

#%% VIŠINE

plt.figure(num=5,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 1. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop1,dH[s1],width,color='r',edgecolor='r',label='1. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=6,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 2. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop2,dH[s2],width1,color='r',edgecolor='r',label='2. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=7,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 3. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop3,dH[s3],width,color='r',edgecolor='r',label='3. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')

plt.figure(num=8,figsize=(16,8),dpi=100,facecolor='w',edgecolor='k')
plt.title('CSRS-PPP 4. serija',fontsize='24')
plt.ylabel('Odstopanja [m]',fontsize='24')
plt.xlabel('Zaporedno število opazovanj [m]',fontsize='24')
plt.grid(True)
plt.bar(sop4,dH[s4],width,color='r',edgecolor='r',label='4. serija')
plt.xticks(fontsize='24')
plt.yticks([0.0,0.2,0.4,0.6,0.8,1.0],fontsize='24')