Datoteke s pora�unanimi aritmetri�nimi sredinami
serij stati�nih opazovanj so: *ime_av.txt

Te datoteke smo s programom SiTraNet pretvorili v D96/TM, 
da smo dobili nadmorske vi�ine to�k.